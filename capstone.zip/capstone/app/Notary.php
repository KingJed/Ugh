<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notary extends Model
{
    //
}
